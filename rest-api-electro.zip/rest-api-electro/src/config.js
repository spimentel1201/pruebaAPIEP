export default {
    SECRET: 'invoices-api'
}